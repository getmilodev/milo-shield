---
name: cost-guardian
description: >-
  Monitors and controls OpenClaw inference spending in real-time. Tracks token
  usage per model, calculates costs, sets budget alerts, and identifies wasteful
  patterns like runaway loops, bloated context, or expensive model misuse.
  Use when: user asks about costs, spending, token usage, budget, "how much am I
  spending", "why is my bill so high", "set a spending limit", "cost breakdown",
  "track my usage", "token burn rate", or mentions unexpected charges.
---

# Cost Guardian — OpenClaw Spending Monitor

## Overview

Cost Guardian tracks what your OpenClaw agent spends on inference, identifies
waste, and helps you stay within budget. Most OpenClaw users have no visibility
into their spending until they get a surprise bill. This skill fixes that.

## Quick Start

```
How much have I spent today?
```

```
Set a daily budget of $5 and alert me if I'm on track to exceed it.
```

## Core Capabilities

### 1. Usage Analysis

When asked about costs, spending, or usage:

1. **Check inference logs:**
   ```bash
   # Find OpenClaw log directory
   ls ~/.openclaw/logs/ 2>/dev/null || ls ~/.config/openclaw/logs/ 2>/dev/null
   ```

2. **Parse recent activity:**
   - Count messages/turns in the last 24h, 7d, 30d
   - Identify which models were used (check config for default_model)
   - Estimate token counts from message lengths (rough: 1 token ≈ 4 chars)

3. **Calculate costs using current pricing:**

   | Model | Input ($/1M tokens) | Output ($/1M tokens) |
   |-------|--------------------|--------------------|
   | claude-sonnet-4-20250514 | $3.00 | $15.00 |
   | claude-opus-4-0 | $15.00 | $75.00 |
   | gpt-4o | $2.50 | $10.00 |
   | gpt-4o-mini | $0.15 | $0.60 |
   | gemini-2.0-flash | $0.10 | $0.40 |
   | gemini-2.0-pro | $1.25 | $5.00 |
   | deepseek-chat | $0.14 | $0.28 |
   | deepseek-reasoner | $0.55 | $2.19 |

4. **Present a clear breakdown:**

```
═══════════════════════════════════════
   COST GUARDIAN — Spending Report
═══════════════════════════════════════

📊 Last 24 Hours:
  Total estimated cost: $X.XX
  Messages sent: XX
  Avg cost per message: $X.XX
  Model breakdown:
    claude-sonnet-4-20250514: XX msgs → $X.XX
    gpt-4o-mini: XX msgs → $X.XX

📈 Trend:
  Today vs yesterday: +XX% / -XX%
  This week vs last week: +XX% / -XX%

⚠️ Waste Detected:
  [List any identified waste patterns]

💡 Savings Opportunities:
  [Specific actionable recommendations]
═══════════════════════════════════════
```

### 2. Waste Detection

Scan for common cost waste patterns:

- **Runaway loops:** Tasks that generated 50+ messages without human intervention
- **Model mismatch:** Using opus/gpt-4o for simple tasks that gpt-4o-mini or flash could handle
- **Context bloat:** Conversations with 100K+ tokens that could have been compacted
- **Retry storms:** Same request failing and retrying repeatedly
- **Cron waste:** Scheduled tasks running more frequently than needed
- **Skill verbosity:** Skills that generate excessive intermediate output

### 3. Budget Management

When asked to set a budget:

1. Create a budget config file:
   ```bash
   mkdir -p ~/.openclaw/cost-guardian
   cat > ~/.openclaw/cost-guardian/budget.json << 'EOF'
   {
     "daily_limit_usd": 5.00,
     "weekly_limit_usd": 25.00,
     "monthly_limit_usd": 80.00,
     "alert_threshold_pct": 80,
     "created": "TIMESTAMP",
     "model_preferences": {
       "simple_tasks": "gpt-4o-mini",
       "complex_tasks": "claude-sonnet-4-20250514",
       "reasoning": "deepseek-reasoner"
     }
   }
   EOF
   ```

2. Offer to set up a daily cost check via cron:
   ```
   Schedule a daily cost report at 9 AM?
   ```
   Cron job name: `cost-guardian:daily-report`

### 4. Optimization Recommendations

Based on usage analysis, suggest:

- **Model downgrades:** "80% of your messages could use gpt-4o-mini instead of sonnet — saves ~$X/week"
- **Context management:** "Your average context is XXK tokens. Enabling compaction could cut costs 40%"
- **Cron optimization:** "Your hourly weather check costs $X/day — switch to every 4 hours"
- **Skill routing:** "Route simple lookups to flash, keep complex reasoning on sonnet"

## Important Rules

- NEVER access or display API keys, just reference them as "configured" or "not configured"
- Cost estimates are ESTIMATES based on message length — actual costs depend on the API provider
- Always clarify that these are estimates, not exact billing data
- Don't modify model settings without explicit approval
- If the user's provider has a dashboard (Anthropic Console, OpenAI Usage), recommend they check it for exact numbers
- Budget alerts are advisory — this skill cannot enforce hard spending limits at the API level
