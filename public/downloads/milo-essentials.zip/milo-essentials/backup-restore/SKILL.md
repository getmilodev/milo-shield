---
name: backup-restore
description: >-
  Automated backup and restore for OpenClaw configurations, memory, skills, and
  workspace files. Creates versioned snapshots, schedules automatic backups, and
  enables one-command rollback. Never lose your agent's configuration or memories
  again.
  Use when: user asks to "backup my config", "save my setup", "restore",
  "rollback", "undo changes", "snapshot", "backup my agent", "disaster recovery",
  "export my config", "migrate", or mentions losing configuration or wanting to
  preserve their current state before making changes.
---

# Backup & Restore — OpenClaw Disaster Recovery

## Overview

One bad config change. One malicious skill. One accidental deletion. Your
carefully configured agent — hours of setup, tuned personality, custom skills,
curated memories — gone.

Backup & Restore creates automatic, versioned snapshots of everything that
matters. One command to backup. One command to restore. Peace of mind.

## Quick Start

```
Backup my entire OpenClaw setup.
```

```
Show me my available backups.
```

```
Restore my config from yesterday's backup.
```

## Core Capabilities

### 1. Full Backup

When asked to backup:

1. **Create backup directory:**
   ```bash
   BACKUP_DIR=~/.openclaw/backups/$(date +%Y%m%d-%H%M%S)
   mkdir -p "$BACKUP_DIR"
   ```

2. **Backup these components:**

   | Component | Source | Why |
   |-----------|--------|-----|
   | Config | `~/.openclaw/config.yaml` | Core agent configuration |
   | Skills | `~/.openclaw/skills/` | All installed skills |
   | Workspace | Current workspace directory | AGENTS.md, SOUL.md, MEMORY.md, USER.md, TOOLS.md |
   | Memory | `memory/` directory | Daily notes, heartbeat state |
   | Cron | OpenClaw cron configuration | Scheduled tasks |
   | Environment | Sanitized env snapshot | Which env vars are set (NOT values) |

3. **Create the backup:**
   ```bash
   # Config
   cp ~/.openclaw/config.yaml "$BACKUP_DIR/config.yaml" 2>/dev/null
   
   # Skills (just SKILL.md files and references, not node_modules)
   mkdir -p "$BACKUP_DIR/skills"
   find ~/.openclaw/skills -name "SKILL.md" -exec cp --parents {} "$BACKUP_DIR/" \; 2>/dev/null
   find ~/.openclaw/skills -name "*.md" -exec cp --parents {} "$BACKUP_DIR/" \; 2>/dev/null
   
   # Workspace identity files
   mkdir -p "$BACKUP_DIR/workspace"
   for f in AGENTS.md SOUL.md USER.md TOOLS.md MEMORY.md HEARTBEAT.md; do
     cp "$f" "$BACKUP_DIR/workspace/" 2>/dev/null
   done
   
   # Memory directory
   cp -r memory/ "$BACKUP_DIR/workspace/memory/" 2>/dev/null
   
   # Cron jobs (list them)
   # Note: actual cron backup method depends on OpenClaw version
   
   # Environment variable names (NOT values — security!)
   env | grep -E "^(OPENCLAW|STRIPE|VERCEL|GEMINI|API)" | cut -d= -f1 > "$BACKUP_DIR/env-vars-list.txt" 2>/dev/null
   ```

4. **Create manifest:**
   ```bash
   cat > "$BACKUP_DIR/manifest.json" << EOF
   {
     "created": "$(date -Iseconds)",
     "type": "full",
     "components": ["config", "skills", "workspace", "memory"],
     "openclaw_version": "$(openclaw --version 2>/dev/null || echo 'unknown')",
     "notes": "USER_PROVIDED_NOTES"
   }
   EOF
   ```

5. **Compress (optional for large backups):**
   ```bash
   tar -czf "$BACKUP_DIR.tar.gz" -C "$(dirname $BACKUP_DIR)" "$(basename $BACKUP_DIR)"
   ```

6. **Report:**
   ```
   ═══════════════════════════════════════
      BACKUP COMPLETE ✅
   ═══════════════════════════════════════
   
   📁 Location: ~/.openclaw/backups/YYYYMMDD-HHMMSS
   📦 Components backed up:
     ✅ Config (config.yaml)
     ✅ Skills (N skills)
     ✅ Workspace (AGENTS.md, SOUL.md, etc.)
     ✅ Memory (N daily files + MEMORY.md)
   
   📊 Total size: X.X MB
   
   To restore: "Restore from backup YYYYMMDD-HHMMSS"
   ═══════════════════════════════════════
   ```

### 2. Restore

When asked to restore:

1. **List available backups:**
   ```bash
   ls -lt ~/.openclaw/backups/ | head -20
   ```

2. **Show backup details:**
   Read the manifest.json from the requested backup.

3. **Offer restore options:**
   - **Full restore** — Replace everything with the backup version
   - **Config only** — Just restore config.yaml
   - **Skills only** — Restore skill files
   - **Workspace only** — Restore AGENTS.md, SOUL.md, MEMORY.md, etc.
   - **Selective** — Pick specific files to restore

4. **Before restoring:**
   - Create a "pre-restore" backup of current state (safety net)
   - Show a diff of what will change (if possible)
   - Get explicit confirmation

5. **Restore process:**
   ```bash
   # Pre-restore safety backup
   PRE_RESTORE=~/.openclaw/backups/pre-restore-$(date +%Y%m%d-%H%M%S)
   mkdir -p "$PRE_RESTORE"
   cp ~/.openclaw/config.yaml "$PRE_RESTORE/" 2>/dev/null
   
   # Then restore requested backup
   cp "$BACKUP_DIR/config.yaml" ~/.openclaw/config.yaml
   # ... etc for each component
   ```

### 3. Scheduled Backups

Offer to set up automatic backups:

- **Daily backup** at midnight: `backup-restore:daily`
- **Pre-change backup** — Remind to backup before config changes
- **Weekly cleanup** — Remove backups older than 30 days to save space

```
Schedule daily backups at midnight?
```

### 4. Quick Snapshot

For rapid "save state before I try something":

```
Take a quick snapshot.
```

Creates a lightweight snapshot of just config.yaml and workspace identity files.
Faster than full backup, suitable for "let me try this change safely."

### 5. Migration Support

When asked to migrate or export:

1. Create a portable backup package
2. Include setup instructions for the new machine
3. List environment variables that need to be re-configured (names only)
4. Generate a migration checklist

```
═══════════════════════════════════════
   MIGRATION PACKAGE
═══════════════════════════════════════

📦 Package: ~/.openclaw/backups/migration-YYYYMMDD.tar.gz

📋 On the new machine:
  1. Install OpenClaw
  2. Extract this package to ~/.openclaw/
  3. Set these environment variables:
     - STRIPE_SECRET_KEY
     - VERCEL_TOKEN
     - [other detected env vars]
  4. Run: openclaw gateway restart
  5. Verify: openclaw security audit

⚠️ API keys are NOT included — 
   set them manually on the new machine.
═══════════════════════════════════════
```

## Backup Rotation Policy

Default retention:
- Keep last 7 daily backups
- Keep last 4 weekly backups (Sunday)
- Keep last 3 monthly backups (1st of month)
- Delete everything else

User can customize retention in `~/.openclaw/cost-guardian/budget.json` (shared config)
or in `~/.openclaw/backups/retention.json`.

## Important Rules

- NEVER backup API keys, tokens, or secrets — only backup their NAMES
- NEVER overwrite existing backups — always create new timestamped directories
- ALWAYS create a safety backup before any restore operation
- ALWAYS get explicit confirmation before restoring (it overwrites current files)
- Compressed backups (.tar.gz) are preferred for anything over 10MB
- Warn if backup directory is getting large (>500MB) and suggest cleanup
- Skills installed via git clone may have large node_modules — exclude those from backups
- If a restore fails, ensure the pre-restore backup is intact for recovery
