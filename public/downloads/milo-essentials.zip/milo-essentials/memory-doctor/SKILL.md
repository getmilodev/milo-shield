---
name: memory-doctor
description: >-
  Diagnoses and fixes OpenClaw context window and memory issues. Detects bloated
  conversations, memory decay, orphaned context, excessive skill loading, and
  context overflow risks. Optimizes memory configuration for performance and cost.
  Use when: user mentions "context too long", "memory issues", "model overflow",
  "context window", "agent forgot", "agent keeps forgetting", "too many tokens",
  "compaction", "memory bloat", "slow responses", "context limit", or their
  agent seems to lose track of conversations.
---

# Memory Doctor — Context & Memory Optimizer

## Overview

Memory Doctor diagnoses why your OpenClaw agent forgets things, runs slow, or
hits context limits. It analyzes your memory configuration, identifies bloat,
and applies fixes to keep your agent sharp and cost-effective.

The #1 complaint in the OpenClaw community after security? "My agent keeps
forgetting things" and "model overflow messages." This skill fixes both.

## Quick Start

```
My agent keeps forgetting things. Can you diagnose it?
```

```
Run a memory health check.
```

## Core Workflow

### Phase 1: Memory Health Assessment

1. **Check OpenClaw configuration:**
   ```bash
   # Find and read the main config
   cat ~/.openclaw/config.yaml 2>/dev/null || cat ~/.config/openclaw/config.yaml 2>/dev/null
   ```
   
   Look for:
   - `context_limit` or `max_tokens` settings
   - Memory/compaction configuration
   - Model default (affects context window size)
   - Number of loaded skills (each consumes context)

2. **Analyze loaded skills' context footprint:**
   ```bash
   # Check total size of all SKILL.md files
   find ~/.openclaw/skills -name "SKILL.md" -exec wc -c {} + 2>/dev/null
   ```
   
   Each loaded skill's SKILL.md consumes context tokens. Too many large skills = less room for conversation.

3. **Check memory files:**
   ```bash
   # Check workspace memory files
   ls -la memory/ 2>/dev/null
   wc -c MEMORY.md 2>/dev/null
   wc -c AGENTS.md 2>/dev/null
   ```
   
   Large MEMORY.md or AGENTS.md files eat into available context.

4. **Check for context overflow indicators:**
   - Look for compaction messages in recent logs
   - Check if `session-state.md` exists (indicates compaction recovery is needed)
   - Look for "[compacted]" or "[truncated]" markers

### Phase 2: Generate Diagnostic Report

```
═══════════════════════════════════════
   MEMORY DOCTOR — Health Report
═══════════════════════════════════════

🧠 Context Budget:
  Model: [model name]
  Max context: [XXX,XXX tokens]
  
  Consumed by system:
    AGENTS.md:     ~X,XXX tokens (XX%)
    SOUL.md:       ~X,XXX tokens (XX%)
    MEMORY.md:     ~X,XXX tokens (XX%)
    Skills (N):    ~X,XXX tokens (XX%)
    Other context: ~X,XXX tokens (XX%)
  ─────────────────────────────
    Total fixed:   ~XX,XXX tokens (XX%)
    Available:     ~XX,XXX tokens (XX%)

📊 Health Score: [A-F]

🔴 Issues Found:
  [List issues with severity]

💊 Recommended Fixes:
  [Prioritized list of fixes]
═══════════════════════════════════════
```

### Phase 3: Common Issues & Fixes

#### Issue: MEMORY.md is too large
**Symptom:** Agent forgets recent things because old memories crowd the context.
**Fix:** Offer to summarize and compress MEMORY.md:
- Archive entries older than 30 days to `memory/archive/`
- Summarize verbose entries into key points
- Remove duplicate or outdated information
- Target: Keep MEMORY.md under 3,000 tokens

#### Issue: Too many skills loaded
**Symptom:** Each skill's SKILL.md consumes context. 10+ skills = thousands of wasted tokens.
**Fix:**
- List all skills with their token footprint
- Identify rarely-used skills
- Suggest disabling skills not used in the last 7 days
- Recommend skill-loading strategies (load on demand vs always-on)

#### Issue: AGENTS.md is bloated
**Symptom:** Over-engineered AGENTS.md with extensive rules nobody reads.
**Fix:** Offer to trim AGENTS.md to essentials:
- Keep core instructions under 1,500 tokens
- Move detailed guidelines to separate reference files
- Remove example code blocks (they're huge token consumers)

#### Issue: No compaction recovery
**Symptom:** After context compaction, agent loses all state and starts fresh.
**Fix:**
- Set up `session-state.md` pattern (explain the format)
- Create a template `session-state.md`
- Add compaction recovery instructions to AGENTS.md

#### Issue: Daily memory files accumulating
**Symptom:** `memory/` directory has months of daily files, never cleaned up.
**Fix:**
- Archive files older than 14 days
- Summarize key events into MEMORY.md
- Set up a cron job for weekly memory maintenance: `memory-doctor:weekly-cleanup`

#### Issue: Model context too small
**Symptom:** Using a model with small context (8K-32K) for long conversations.
**Fix:** Recommend model upgrade:
- For long conversations: claude-sonnet (200K context)
- For short tasks: gpt-4o-mini (128K context, cheap)
- Explain the cost tradeoff

### Phase 4: Optimization

After diagnosis, offer numbered options:

1. **Quick fix** — Apply the top 3 recommendations automatically
2. **Full optimization** — Comprehensive cleanup with backups
3. **Show commands only** — Copy-paste ready
4. **Set up maintenance** — Weekly cron job to keep things clean

For the maintenance cron, create `memory-doctor:weekly-cleanup` that:
- Archives old daily memory files
- Checks MEMORY.md size
- Reports context budget usage
- Alerts if any file has grown past its threshold

## Scoring Rubric

- **A (90-100):** Lean context, good compaction recovery, maintained memory
- **B (75-89):** Minor bloat, mostly well-configured
- **C (60-74):** Noticeable bloat, missing compaction recovery
- **D (40-59):** Severe bloat, frequent overflow, poor memory hygiene
- **F (0-39):** Context constantly full, agent barely functional

## Important Rules

- ALWAYS create backups before modifying any memory files
- NEVER delete memory files without explicit approval — move to archive
- Token counts are estimates (1 token ≈ 4 characters for English text)
- Don't modify SOUL.md or USER.md without approval — those are identity files
- If MEMORY.md contains sensitive information, warn the user before suggesting it be moved/archived
- Recommend but don't enforce model changes
